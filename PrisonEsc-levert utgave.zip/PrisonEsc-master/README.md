# PrisonEsc
_Even Klemsdal, Henrik Flemmen & Simen Burud_

## Beskrivelse
Spillet handler om en fange (du) som rømmer fra fengsel med å kaste seg ut av et vindu i
fengselscellen. Spilleren prøve å komme så langt han kan før han lander på bakken. Man
kjøper ulike “upgrades” av en cellekamerat. Strekmann-grafikk da ingen av oss kan tegne.
Skal spilles på Android i landscape-mode (liggende vindu). Kontrolltypene blir med
accelerometeret og trykking på skjerm.

OBS: Spillet er basert på å "grinde" en stund – for å slippe det, trykk på "Dave's Shop"-overskriften for instant money.

## Installer
For kjapp installasjon av appen, gå til http://app.simen.codes/prisonesc på en Android-mobil og last ned fila som ligger der.
Husk at du kanskje må slå på "Ukjente kilder" i sikkerhetsinnstillingene først.

Skal fungere på Android 5+, men er bare testet ordentlig på Android 6+.

## Bygge prosjektet
Åpne prosjektmappa i Android Studio 2.3 (ikke "PrisonEsc/app", men "PrisonEsc"). Trykk deg gjennom med standardvalg hele veien. Trykk run, og følg instruksjoner fra Studio.
